const cloudinary = require("cloudinary").v2;

cloudinary.config({
  cloud_name: "ddidzcrhe",
  api_key: "436789553979268",
  api_secret: "g5Fb7hw2M7eWZJsu66WSDZIfubc",
});

module.exports = cloudinary;
